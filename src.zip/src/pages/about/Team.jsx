
import Committee from "./Committee";
import ASC from "./ASC";

export default function Team() {
  return (
    <main>
      <Committee />
      <ASC />
    </main>
  );
}
